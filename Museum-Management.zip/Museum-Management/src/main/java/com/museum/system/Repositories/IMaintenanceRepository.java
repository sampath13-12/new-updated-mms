package com.museum.system.Repositories;

import com.museum.system.Entities.Maintenance;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IMaintenanceRepository extends JpaRepository<Maintenance,Long> {
}
