package com.museum.system.Services.Impl;

import com.museum.system.Entities.VirtualTour;
import com.museum.system.Repositories.IVirtualTourRepository;
import com.museum.system.Services.IVirtualTourService;
import org.springframework.stereotype.Service;

@Service
public class VirtualTourService implements IVirtualTourService {

    private IVirtualTourRepository virtualTourRepository;

    @Override
    public VirtualTour save(VirtualTour virtualTour) {
        return virtualTourRepository.save(virtualTour);
    }
}
