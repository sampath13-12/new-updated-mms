package com.museum.system.Services;

import com.museum.system.Entities.User;

import java.util.Optional;

public interface IUserService {

    public User createUser(User user) ;

    public Optional<User> findByUsername(String username) ;

    Optional<User> findById(Long userId);

    void save(User user);

    public Optional<User> login(String username, String password) ;
}
