package com.museum.system.Services.Impl;

import com.museum.system.Entities.Loan;
import com.museum.system.Repositories.ILoanRepository;
import com.museum.system.Services.ILoanService;
import com.museum.system.dtos.LoanDto;
import com.museum.system.dtos.NotificationDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LoanService implements ILoanService {

    @Autowired
    private ILoanRepository loanRepository;

    @Override
    public Loan requestLoan(Loan loan) {
        return loanRepository.save(loan);
    }

    @Override
    public String getLoanStatus(Long loanId) {
        return "";
    }

    @Override
    public List<NotificationDto> getNotifications() {
        return List.of();
    }

    @Override
    public void approveLoan(Long loanId) {

    }

    @Override
    public List<LoanDto> getLoanedArtifacts() {
        return List.of();
    }
}
