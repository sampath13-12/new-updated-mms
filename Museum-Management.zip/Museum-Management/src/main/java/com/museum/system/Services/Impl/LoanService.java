package com.museum.system.Services.Impl;

import aj.org.objectweb.asm.commons.InstructionAdapter;
import com.museum.system.Entities.Artifact;
import com.museum.system.Entities.Loan;
import com.museum.system.Entities.User;
import com.museum.system.Repositories.IArtifactRepository;
import com.museum.system.Repositories.ILoanRepository;
import com.museum.system.Repositories.IUserRepository;
import com.museum.system.Services.ILoanService;
import com.museum.system.dtos.LoanDto;
import com.museum.system.dtos.LoanRequestDto;
import com.museum.system.dtos.NotificationDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class LoanService implements ILoanService {

    @Autowired
    private ILoanRepository loanRepository;

    @Autowired
    private IArtifactRepository artifactRepository;

    @Autowired
    private IUserRepository userRepository;

    private List<NotificationDto> notifications = new ArrayList<>();

    @Override
    public Loan requestLoan(LoanRequestDto loanRequestDto) {
        Artifact artifact = artifactRepository.findById(loanRequestDto.getArtifactId())
                .orElseThrow(() -> new RuntimeException("Artifact not found"));

        User businessPartner = userRepository.findById(loanRequestDto.getBusinessPartnerId())
                .orElseThrow(() -> new RuntimeException("Business Partner not found"));

        Loan loan = new Loan();
        loan.setArtifact(artifact);
        loan.setBusinessPartner(businessPartner);
        loan.setLoanDate(LocalDate.now());  // Default to today's date
        loan.setReturnDate(LocalDate.now().plusMonths(Integer.parseInt(loanRequestDto.getLoanDuration())));  // Assuming loanDuration is in months
        loan.setStatus("Requested");

        return loanRepository.save(loan);
    }

    @Override
    public String getLoanStatus(Long loanId) {
        Loan loan = loanRepository.findById(loanId).orElse(null);
        return loan != null ? loan.getStatus() : "Loan not found";
    }

    @Override
    public List<LoanDto> getLoanedArtifacts() {
        List<Loan> loans = loanRepository.findAll();
        List<LoanDto> loanDtos = new ArrayList<>();
        for (Loan loan : loans) {
            loanDtos.add(new LoanDto(
                    loan.getArtifact().getId(),
                    loan.getArtifact().getName(),
                    loan.getStatus()));
        }
        return loanDtos;
    }

    @Override
    public boolean approveLoan(Long loanId) {
        Loan loan = loanRepository.findById(loanId).orElse(null);
        if (loan != null) {
            loan.setStatus("Approved");
            loanRepository.save(loan);
            notifications.add(new NotificationDto(loanId, "Loan for artifact " + loan.getArtifact().getName() + " has been approved."));
            return true;
        }
        return false;
    }

    @Override
    public List<NotificationDto> getNotifications() {
        // In this example, notifications are just simple strings
        List<NotificationDto> notifications = new ArrayList<>();
        notifications.add(new NotificationDto(1L, "Loan approved"));
        return notifications;
    }
}

