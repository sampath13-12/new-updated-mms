package com.museum.system.dtos;

public class DisplayAreaDto {
    private String areaName;
    private String location;
    private String layout;


    public DisplayAreaDto() {
    }

    public DisplayAreaDto(String areaName, String location, String layout) {
        this.areaName = areaName;
        this.location = location;
        this.layout = layout;
    }


    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getLayout() {
        return layout;
    }

    public void setLayout(String layout) {
        this.layout = layout;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }


    @Override
    public String toString() {
        return "DisplayAreaDto{" +
                "areaName='" + areaName + '\'' +
                ", location='" + location + '\'' +
                ", layout='" + layout + '\'' +
                '}';
    }
}
