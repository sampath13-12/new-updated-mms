package com.museum.system.Services;

import com.museum.system.Entities.Loan;
import com.museum.system.dtos.LoanDto;
import com.museum.system.dtos.LoanRequestDto;
import com.museum.system.dtos.NotificationDto;

import java.util.List;

public interface ILoanService {

    List<LoanDto> getLoanedArtifacts();

    public Loan requestLoan(LoanRequestDto loanRequestDto) ;

    String getLoanStatus(Long loanId);

    List<NotificationDto> getNotifications();

    boolean approveLoan(Long loanId);

}
