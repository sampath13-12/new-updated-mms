package com.museum.system.dtos;

public class LoanDto {
    private Long artifactId;
    private String artifactName;
    private String loanStatus;

    public LoanDto() {
    }

    public LoanDto(Long artifactId, String artifactName, String loanStatus) {
        this.artifactId = artifactId;
        this.artifactName = artifactName;
        this.loanStatus = loanStatus;
    }


    public Long getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(Long artifactId) {
        this.artifactId = artifactId;
    }

    public String getArtifactName() {
        return artifactName;
    }

    public void setArtifactName(String artifactName) {
        this.artifactName = artifactName;
    }

    public String getLoanStatus() {
        return loanStatus;
    }

    public void setLoanStatus(String loanStatus) {
        this.loanStatus = loanStatus;
    }

    @Override
    public String toString() {
        return "LoanDto{" +
                "artifactId=" + artifactId +
                ", artifactName='" + artifactName + '\'' +
                ", loanStatus='" + loanStatus + '\'' +
                '}';
    }
}