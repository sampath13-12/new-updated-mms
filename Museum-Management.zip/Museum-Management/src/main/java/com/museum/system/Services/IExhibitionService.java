package com.museum.system.Services;

import com.museum.system.Entities.Exhibition;
import com.museum.system.dtos.ExhibitionDto;

import java.util.List;

public interface IExhibitionService {
    public Exhibition createExhibition(Exhibition exhibition) ;

    List<Exhibition> getAllExhibitions();

    List<ExhibitionDto> getExhibitions();
}
