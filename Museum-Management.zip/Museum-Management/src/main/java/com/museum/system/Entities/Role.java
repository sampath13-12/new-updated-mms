package com.museum.system.Entities;

public enum Role {
    ADMIN,
    EMPLOYEE,
    CURATOR,
    BUSINESS_PARTNER,
    GENERAL_PUBLIC,
    INSURANCE_SECURITY;
}
