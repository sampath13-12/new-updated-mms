package com.museum.system.Services.Impl;

import com.museum.system.Repositories.IUserRepository;
import com.museum.system.Services.IAdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminService implements IAdminService {

    @Autowired
    private IUserRepository userRepository;



}
