package com.museum.system.Services;

import com.museum.system.Entities.Notification;
import com.museum.system.dtos.NotificationDto;

import java.util.List;

public interface INotificationService {
    public Notification createNotification(Notification notification) ;

    List<NotificationDto> getNotifications();
}
