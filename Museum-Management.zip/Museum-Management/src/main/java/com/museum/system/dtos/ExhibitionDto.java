package com.museum.system.dtos;

public class ExhibitionDto {
    private Long exhibitionId;
    private String title;
    private String description;

    public ExhibitionDto() {
    }

    public ExhibitionDto(Long exhibitionId, String title, String description) {
        this.exhibitionId = exhibitionId;
        this.title = title;
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Long getExhibitionId() {
        return exhibitionId;
    }

    public void setExhibitionId(Long exhibitionId) {
        this.exhibitionId = exhibitionId;
    }

    @Override
    public String toString() {
        return "ExhibitionDto{" +
                "description='" + description + '\'' +
                ", exhibitionId=" + exhibitionId +
                ", title='" + title + '\'' +
                '}';
    }
}
