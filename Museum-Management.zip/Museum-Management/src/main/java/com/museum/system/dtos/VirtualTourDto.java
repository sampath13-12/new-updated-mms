package com.museum.system.dtos;

public class VirtualTourDto {
    private Long tourId;
    private String tourName;


    public VirtualTourDto() {
    }

    public VirtualTourDto(Long tourId, String tourName) {
        this.tourId = tourId;
        this.tourName = tourName;
    }

    public Long getTourId() {
        return tourId;
    }

    public void setTourId(Long tourId) {
        this.tourId = tourId;
    }

    public String getTourName() {
        return tourName;
    }

    public void setTourName(String tourName) {
        this.tourName = tourName;
    }

    @Override
    public String toString() {
        return "VirtualTourDto{" +
                "tourId=" + tourId +
                ", tourName='" + tourName + '\'' +
                '}';
    }
}
