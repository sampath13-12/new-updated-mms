package com.museum.system.dtos;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VirtualTourDto {
    private Long tourId;
    private String tourName;
    private Long userId; // User joining the tour
    private Long exhibitionId; // Exhibition associated with the tour
    private String tourDate; // Date of the tour (e.g., "2024-12-01")


    @Override
    public String toString() {
        return "VirtualTourDto{" +
                "tourId=" + tourId +
                ", tourName='" + tourName + '\'' +
                ", userId=" + userId +
                ", exhibitionId=" + exhibitionId +
                ", tourDate='" + tourDate + '\'' +
                '}';
    }
}
