package com.museum.system.Repositories;

import com.museum.system.Entities.Artifact;
import com.museum.system.dtos.ArtifactDto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IArtifactRepository extends JpaRepository<Artifact, Long> {
}
