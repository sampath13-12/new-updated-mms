package com.museum.system.Services;

import com.museum.system.Entities.VirtualTour;

public interface IVirtualTourService {
    public VirtualTour save(VirtualTour virtualTour);
}
