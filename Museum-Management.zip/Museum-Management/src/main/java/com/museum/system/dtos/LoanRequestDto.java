package com.museum.system.dtos;

public class LoanRequestDto {
    private Long artifactId;
    private String loanDuration;

    public LoanRequestDto() {
    }

    public LoanRequestDto(Long artifactId, String loanDuration) {
        this.artifactId = artifactId;
        this.loanDuration = loanDuration;
    }

    public String getLoanDuration() {
        return loanDuration;
    }

    public void setLoanDuration(String loanDuration) {
        this.loanDuration = loanDuration;
    }

    public Long getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(Long artifactId) {
        this.artifactId = artifactId;
    }

    @Override
    public String toString() {
        return "LoanRequestDto{" +
                "artifactId=" + artifactId +
                ", loanDuration='" + loanDuration + '\'' +
                '}';
    }
}