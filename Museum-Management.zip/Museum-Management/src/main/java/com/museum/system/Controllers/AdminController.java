package com.museum.system.Controllers;


import com.museum.system.Entities.Role;
import com.museum.system.Entities.User;

import com.museum.system.Services.IUserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("api/admin")
public class AdminController {

    Logger logger = LoggerFactory.getLogger(AdminController.class);

    @Autowired
    private IUserService userService;

    @PostMapping("/message")
    public Map<String, String> msg(){
        return Map.of("msg","Connection in admin controller");
    }

    @PostMapping("/add-user")
    public ResponseEntity<?> addUser(@RequestBody User user) {
        HashMap<String, Object> response = new HashMap<>();
        try{
            logger.warn("{} is registered and role is {}",user.getUsername(),user.getRole());
            if(user.getUsername() == null && user.getPassword() == null){
                response.put("msg","username and password fields are required");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }
            User createdUser = userService.createUser(user);
            response.put("msg","User added successfully");
            response.put("userID",createdUser.getId());
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        }
        catch (RuntimeException e){
            response.put("msg",e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
        }
        catch (Exception e){
            response.put("msg","An error occured during add a user");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }

    }

    @PutMapping("/update-permission/{userId}")
    public ResponseEntity<?> updatePermission(@PathVariable Long userId, @RequestBody String role) {
        Map<String, Object> response = new HashMap<>();
        try {
            Optional<User> user = userService.findById(userId);

            if (user.isPresent()) {
                User updatedUser = user.get();
                updatedUser.setRole(Role.valueOf(role));

                userService.save(updatedUser);

                response.put("message", "User role updated successfully.");
                response.put("updatedUser", updatedUser);
                return ResponseEntity.ok().body(response);
            } else {
                response.put("msg", "User with ID " + userId + " not found. Update failed.");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }
        } catch (IllegalArgumentException e) {
            response.put("message", "Invalid role provided: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        } catch (Exception e) {
            response.put("message", "An error occurred while updating the user role: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @GetMapping("/getuser/{userId}")
    public ResponseEntity<?> getUser(@PathVariable Long userId){
        HashMap<String,Object> response =  new HashMap<>();
        try {
            Optional<User> user = userService.findById(userId);

            if (user.isPresent()) {
                return new ResponseEntity<>(user.get(), HttpStatus.OK);  // Return user if found
            } else {
                response.put("msg","user with ID "+ userId +" not found");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletRequest request) {
        try{
            HttpSession session = request.getSession(false);
            if(session!=null){
                session.invalidate();
            }
            return new ResponseEntity<>(Map.of("msg","Logout successful"),HttpStatus.OK);
        }
        catch (Exception e){
            return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }
}