package com.museum.system.Entities;

import com.museum.system.dtos.LoanRequestDto;
import jakarta.persistence.Entity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
public class Loan extends LoanRequestDto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private LocalDate loanDate;
    private LocalDate returnDate;
    private String status; // Pending, Approved, Returned

    @ManyToOne
    private Artifact artifact;

    @ManyToOne
    private User businessPartner;
}
