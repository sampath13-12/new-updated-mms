package com.museum.system.Services;

import com.museum.system.Entities.Ticket;

public interface ITicketService {
    public Ticket purchaseTicket(Ticket ticket) ;
}
