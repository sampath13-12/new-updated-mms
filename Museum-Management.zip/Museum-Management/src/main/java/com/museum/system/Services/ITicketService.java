package com.museum.system.Services;

import com.museum.system.Entities.Ticket;
import com.museum.system.dtos.TicketDto;

public interface ITicketService {
    public Ticket purchaseTicket(TicketDto ticketDto) ;
}
