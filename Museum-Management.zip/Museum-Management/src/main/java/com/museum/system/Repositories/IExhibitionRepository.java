package com.museum.system.Repositories;

import com.museum.system.Entities.Exhibition;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IExhibitionRepository extends JpaRepository<Exhibition, Long> {
}
