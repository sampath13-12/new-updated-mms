package com.museum.system.dtos;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TicketDto {
    private String ticketNumber;
    private LocalDate date;
    private BigDecimal price;
    private Long userId;
}