package com.museum.system.Services;

import com.museum.system.Entities.DisplayArea;
import com.museum.system.dtos.DisplayAreaDto;

import java.util.List;
import java.util.Optional;

public interface IDisplayAreaService {

    public DisplayArea createDisplayArea(DisplayArea displayArea) ;

    void updateDisplayArea(Long areaId, DisplayAreaDto displayAreaDto);
}
