package com.museum.system.Services;

import com.museum.system.Entities.DisplayArea;
import com.museum.system.dtos.DisplayAreaDto;

import java.util.List;

public interface IDisplayAreaService {

    public DisplayArea createDisplayArea(DisplayArea displayArea) ;

    boolean updateDisplayArea(Long areaId, DisplayAreaDto displayAreaDto);

    public void addDisplayArea(DisplayAreaDto displayAreaDto) ;

    public List<DisplayAreaDto> getAllDisplayAreas() ;
}
