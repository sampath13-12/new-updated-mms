package com.museum.system.dtos;

import java.time.LocalDateTime;

public class EventNotificationDto {
    private Long eventId;
    private String message;
    private LocalDateTime timestamp;

    public EventNotificationDto() {
    }

    public EventNotificationDto(Long eventId, String message, LocalDateTime timestamp) {
        this.eventId = eventId;
        this.message = message;
        this.timestamp = timestamp;
    }

    public Long getEventId() {
        return eventId;
    }

    public void setEventId(Long eventId) {
        this.eventId = eventId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "EventNotificationDto{" +
                "eventId=" + eventId +
                ", message='" + message + '\'' +
                ", timestamp=" + timestamp +
                '}';
    }
}
