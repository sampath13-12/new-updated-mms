package com.museum.system.dtos;

public class NotificationDto {
    private Long loanId;
    private String message;

    public NotificationDto(Long loanId, String message) {
        this.loanId = loanId;
        this.message = message;
    }

    public Long getLoanId() {
        return loanId;
    }

    public void setLoanId(Long loanId) {
        this.loanId = loanId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "NotificationDto{" +
                "loanId=" + loanId +
                ", message='" + message + '\'' +
                '}';
    }
}
