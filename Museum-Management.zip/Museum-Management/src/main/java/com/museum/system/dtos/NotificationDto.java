package com.museum.system.dtos;

import java.time.LocalDateTime;

public class NotificationDto {
    private Long notificationId;
    private String message;
    private LocalDateTime timestamp;

    public NotificationDto() {
    }

    public NotificationDto(Long notificationId, String message, LocalDateTime timestamp) {
        this.notificationId = notificationId;
        this.message = message;
        this.timestamp = timestamp;
    }


    public Long getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(Long notificationId) {
        this.notificationId = notificationId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "NotificationDto{" +
                "message='" + message + '\'' +
                ", notificationId=" + notificationId +
                ", timestamp=" + timestamp +
                '}';
    }
}
