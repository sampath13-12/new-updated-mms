package com.museum.system.Controllers;

import com.museum.system.Entities.Exhibition;
import com.museum.system.Entities.User;
import com.museum.system.Entities.VirtualTour;
import com.museum.system.Services.Impl.ExhibitionService;
import com.museum.system.Services.Impl.TicketService;
import com.museum.system.Services.Impl.UserService;
import com.museum.system.Services.Impl.VirtualTourService;
import com.museum.system.dtos.LoginDto;
import com.museum.system.dtos.RegisterDto;
import com.museum.system.dtos.TicketDto;
import com.museum.system.dtos.VirtualTourDto;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("api/public")
public class GeneralPublicController {

    @Autowired
    private ExhibitionService exhibitionService;

    @Autowired
    private TicketService ticketService;

    @Autowired
    private UserService userService;

    @Autowired
    private VirtualTourService virtualTourService;

    @PostMapping("/message")
    public Map<String, String> msg() {
        return Map.of("msg", "Connection in General Public Controller");
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterDto registerDto) {
        HashMap<String, String> response = new HashMap<>();
        try {
            userService.registerUser(registerDto);
            response.put("msg", "Registration successful");
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (IllegalArgumentException e) {
            response.put("msg", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        } catch (Exception e) {
            response.put("msg", "Error occurred during registration");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }


    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginDto loginDto) {
        HashMap<String, Object> response = new HashMap<>();
        try {
            Optional<User> user = userService.login(loginDto.getUsername(), loginDto.getPassword());
            if (user.isPresent()) {
                response.put("msg", "Logged in successfully");
                response.put("userId", user.get().getId());
                response.put("username", user.get().getUsername());
                return ResponseEntity.ok(response);
            } else {
                response.put("msg", "Invalid username or password");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }
        } catch (Exception e) {
            response.put("msg", "Error occurred during login");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @GetMapping("/exhibitions")
    public ResponseEntity<?> getExhibitions() {
        try {
            List<Exhibition> exhibitions = exhibitionService.getAllExhibitions();
            return ResponseEntity.ok(exhibitions);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("msg", "Error occurred while fetching exhibitions"));
        }
    }

    @PostMapping("/tickets/purchase")
    public ResponseEntity<?> purchaseTickets(@RequestBody TicketDto ticketDto) {
        HashMap<String, String> response = new HashMap<>();
        try {
            ticketService.purchaseTicket(ticketDto);
            response.put("msg", "Ticket purchased successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("msg", "Error occurred while purchasing ticket");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PostMapping("/virtual-tour/join")
    public ResponseEntity<?> joinVirtualTour(@RequestBody VirtualTourDto virtualTourDto) {
        HashMap<String, String> response = new HashMap<>();
        try {
            // Validate the user
            User user = userService.findById(virtualTourDto.getUserId())
                    .orElseThrow(() -> new RuntimeException("User not found"));

            // Validate the exhibition
            Exhibition exhibition = exhibitionService.findById(virtualTourDto.getExhibitionId())
                    .orElseThrow(() -> new RuntimeException("Exhibition not found"));

            // Process the virtual tour
            // Here, you might save the virtual tour details in the database or handle other business logic
            VirtualTour virtualTour = new VirtualTour(); // Assuming a VirtualTour entity exists
            virtualTour.setTourName(virtualTourDto.getTourName());
            virtualTour.setTourDate(LocalDate.parse(virtualTourDto.getTourDate()));
            virtualTour.setUser(user);
            virtualTour.setExhibition(exhibition);

            // Save the virtual tour (You might need a VirtualTourService for this)
            virtualTourService.save(virtualTour);

            response.put("msg", "Virtual tour joined successfully");
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (IllegalArgumentException e) {
            response.put("msg", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        } catch (Exception e) {
            response.put("msg", "Error occurred while joining virtual tour");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }





    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletRequest request) {
        try {
            HttpSession session = request.getSession(false);
            if (session != null) {
                session.invalidate();
            }
            return new ResponseEntity<>(Map.of("msg", "Logout successful"), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(Map.of("msg", "Error occurred during logout"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
