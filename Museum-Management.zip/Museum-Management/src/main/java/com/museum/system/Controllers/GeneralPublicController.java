package com.museum.system.Controllers;

import com.museum.system.Entities.Exhibition;
import com.museum.system.Entities.Ticket;
import com.museum.system.Services.Impl.ExhibitionService;
import com.museum.system.Services.Impl.TicketService;
import com.museum.system.dtos.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("api/public")
public class GeneralPublicController {
    @Autowired
    private ExhibitionService exhibitionService;
    @Autowired
    private TicketService ticketService;


    @PostMapping("/message")
    public Map<String, String> msg(){
        return Map.of("msg","Connection in general public controller");
    }

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody RegisterDto registerDto) {
        return ResponseEntity.ok("Registered successfully");
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginDto loginDto) {
        return ResponseEntity.ok("Logged in successfully");
    }

    @GetMapping("/exhibitions")
    public ResponseEntity<List<ExhibitionDto>> getExhibitions() {
        List<ExhibitionDto> exhibitions = exhibitionService.getExhibitions();
        return ResponseEntity.ok(exhibitions);
    }

    @PostMapping("/tickets/purchase")
    public ResponseEntity<String> purchaseTickets(@RequestBody TicketDto ticketDto) {
        ticketService.purchaseTicket((Ticket) ticketDto);
        return ResponseEntity.ok("Ticket purchased successfully");
    }

    @PostMapping("/virtual-tours/join")
    public ResponseEntity<String> joinVirtualTour(@RequestBody VirtualTourDto virtualTourDto) {
        return ResponseEntity.ok("Joined virtual tour successfully");
    }

    @GetMapping("/notifications")
    public ResponseEntity<List<EventNotificationDto>> getNotifications() {
        return ResponseEntity.ok(new ArrayList<>());
    }

    @PostMapping("/logout")
    public ResponseEntity<String> logout() {
        return ResponseEntity.ok("Logged out successfully");
    }
}
