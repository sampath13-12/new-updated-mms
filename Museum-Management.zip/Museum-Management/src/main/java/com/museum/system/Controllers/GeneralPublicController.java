package com.museum.system.Controllers;

import com.museum.system.Services.Impl.ExhibitionService;
import com.museum.system.Services.Impl.TicketService;
import com.museum.system.Services.Impl.VirtualTourService;
import com.museum.system.dtos.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("api/public")
public class GeneralPublicController {

    private final ExhibitionService exhibitionService;
    private final TicketService ticketService;
    private final VirtualTourService virtualTourService;

    @Autowired
    public GeneralPublicController(ExhibitionService exhibitionService,
                                   TicketService ticketService,
                                   VirtualTourService virtualTourService) {
        this.exhibitionService = exhibitionService;
        this.ticketService = ticketService;
        this.virtualTourService = virtualTourService;
    }

    // Test endpoint to verify controller is working
    @PostMapping("/message")
    public ResponseEntity<Map<String, String>> msg() {
        return ResponseEntity.ok(Map.of("msg", "Connection in general public controller"));
    }

    // Register a new user
    @PostMapping("/register")
    public ResponseEntity<Map<String, String>> register(@RequestBody RegisterDto registerDto) {
        // Registration logic can be added here
        return buildResponse("Registered successfully", HttpStatus.CREATED);
    }

    // Login user
    @PostMapping("/login")
    public ResponseEntity<Map<String, String>> login(@RequestBody LoginDto loginDto) {
        // Authentication logic can be added here
        return buildResponse("Logged in successfully", HttpStatus.OK);
    }

    // Fetch all exhibitions
    @GetMapping("/exhibitions")
    public ResponseEntity<List<ExhibitionDto>> getExhibitions() {
        List<ExhibitionDto> exhibitions = exhibitionService.getExhibitions();
        return ResponseEntity.ok(exhibitions);
    }

    // Purchase tickets for an exhibition
    @PostMapping("/tickets/purchase")
    public ResponseEntity<Map<String, String>> purchaseTickets(@RequestBody TicketDto ticketDto) {
        try {
            ticketService.purchaseTicket(ticketDto);
            return buildResponse("Ticket purchased successfully", HttpStatus.OK);
        } catch (Exception e) {
            return buildErrorResponse("Error occurred while purchasing the ticket", e);
        }
    }

    // Join a virtual tour
    @PostMapping("/virtual-tours/join")
    public ResponseEntity<Map<String, String>> joinVirtualTour(@RequestBody VirtualTourDto virtualTourDto) {
        try {
            virtualTourService.joinTour(virtualTourDto);
            return buildResponse("Joined virtual tour successfully", HttpStatus.OK);
        } catch (Exception e) {
            return buildErrorResponse("Error occurred while joining the virtual tour", e);
        }
    }

    // Get notifications (e.g., event updates, reminders)
    @GetMapping("/notifications")
    public ResponseEntity<List<EventNotificationDto>> getNotifications() {
        List<EventNotificationDto> notifications = new ArrayList<>();  // Replace with actual notification service
        return ResponseEntity.ok(notifications);
    }

    // Logout user
    @PostMapping("/logout")
    public ResponseEntity<Map<String, String>> logout() {
        // Implement actual logout logic if needed
        return buildResponse("Logged out successfully", HttpStatus.OK);
    }

    // Utility method to build successful responses
    private ResponseEntity<Map<String, String>> buildResponse(String message, HttpStatus status) {
        return ResponseEntity.status(status).body(Map.of("msg", message));
    }

    // Utility method to build error responses
    private ResponseEntity<Map<String, String>> buildErrorResponse(String message, Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "msg", message,
                "error", e.getMessage()
        ));
    }
}
