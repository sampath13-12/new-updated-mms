package com.museum.system.dtos;

import java.time.LocalDateTime;

public class ArtifactStatusDto {

    private Long artifactId;
    private String status;  // e.g., "On Display", "In Maintenance", "Stored"
    private String description;  // Optional description about the status
    private LocalDateTime lastUpdated;  // Timestamp when the status was last updated

    // Default constructor
    public ArtifactStatusDto() {}

    // Parameterized constructor
    public ArtifactStatusDto(Long artifactId, String status, String description, LocalDateTime lastUpdated) {
        this.artifactId = artifactId;
        this.status = status;
        this.description = description;
        this.lastUpdated = lastUpdated;
    }

    // Getters and setters
    public Long getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(Long artifactId) {
        this.artifactId = artifactId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(LocalDateTime lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    // toString() for logging
    @Override
    public String toString() {
        return "ArtifactStatusDto{" +
                "artifactId=" + artifactId +
                ", status='" + status + '\'' +
                ", description='" + description + '\'' +
                ", lastUpdated=" + lastUpdated +
                '}';
    }
}
