package com.museum.system.Services.Impl;

import com.museum.system.Entities.Exhibition;
import com.museum.system.Repositories.IExhibitionRepository;
import com.museum.system.Services.IExhibitionService;
import com.museum.system.dtos.ExhibitionDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ExhibitionService implements IExhibitionService {

    @Autowired
    private IExhibitionRepository exhibitionRepository;

    @Override
    public Exhibition createExhibition(Exhibition exhibition) {
        return null;
    }

    @Override
    public List<Exhibition> getAllExhibitions() {
        return List.of();
    }

    @Override
    public List<ExhibitionDto> getExhibitions() {
        return List.of();
    }
}
