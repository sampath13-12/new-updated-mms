package com.museum.system.Repositories;

import com.museum.system.Entities.Notification;
import org.springframework.data.jpa.repository.JpaRepository;

public interface INotificationRepository  extends JpaRepository<Notification, Long> {
}
