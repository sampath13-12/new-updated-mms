package com.museum.system.Controllers;

import com.museum.system.Entities.Artifact;
import com.museum.system.Entities.Role;
import com.museum.system.Entities.User;
import com.museum.system.Services.IArtifactService;
import com.museum.system.Services.Impl.DisplayAreaService;
import com.museum.system.Services.Impl.UserService;
import com.museum.system.dtos.ArtifactStatusDto;
import com.museum.system.dtos.LoginDto;
import com.museum.system.dtos.MaintenanceDto;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Handler;

@RestController
@RequestMapping("api/employee")
public class EmployeeController {

    @Autowired
    private IArtifactService artifactService;

    @Autowired
    private DisplayAreaService displayAreaService;

    @Autowired
    private UserService userService;

    @PostMapping("/message")
    public Map<String, String> msg(){
        return Map.of("msg","Connection in employee controller");
    }

    @PostMapping("/assign-artifact")
    public ResponseEntity<Artifact> assignArtifact(@RequestBody Artifact artifact) {
        return ResponseEntity.ok(artifactService.createArtifact(artifact));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody HashMap<String,String> loginDto) {
        HashMap<String,Object> response =new HashMap<>();
        try{
            String username = loginDto.get("username");
            String password = loginDto.get("password");

            if(username == null && password == null){
                response.put("msg","Username and password fields are required");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }

            Optional<User> userDetails = userService.login(username, password);
            if(userDetails.isPresent()){
                User user = userDetails.get();

                if(user.getRole() == Role.EMPLOYEE){
                    response.put("msg","Employee logged in successfully");
                    response.put("userID",userDetails.get().getId());
                    response.put("username",userDetails.get().getUsername());
                    return ResponseEntity.ok(response);
                }
                else {
                    response.put("msg", "Access denied: Only employees can log in");
                    return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
                }
            }
            else{
                response.put("msg","Invalid username and password");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }
        }
        catch (Exception e){
            response.put("msg","An error occured during login");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PutMapping("/display-areas/{areaId}/assign")
    public ResponseEntity<?> assignArtifacts(@PathVariable Long areaId, @RequestBody List<Long> artifactIds) {
        HashMap<String, Object> response = new HashMap<>();

        try {
            if (artifactIds == null || artifactIds.isEmpty()) {
                response.put("msg", "Artifact list cannot be empty");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }

            boolean isAssigned = displayAreaService.assignArtifacts(areaId, artifactIds);

            if (isAssigned) {
                response.put("msg", "Artifacts assigned successfully");
                response.put("areaId", areaId);
                response.put("artifactIds", artifactIds);
                return ResponseEntity.ok(response);
            } else {
                response.put("msg", "Failed to assign artifacts to the display area");
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
            }

        } catch (Exception e) {
            response.put("msg", "An error occurred while assigning artifacts");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PostMapping("/maintenance/schedule")
    public ResponseEntity<?> scheduleMaintenance(@RequestBody MaintenanceDto maintenanceDto) {
        HashMap<String, Object> response = new HashMap<>();

        try {
            if (maintenanceDto.getAreaId() == null || maintenanceDto.getScheduledTime() == null) {
                response.put("msg", "Area ID and Scheduled Time are required");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }

            if (maintenanceDto.getMaintenanceDetails() == null || maintenanceDto.getMaintenanceDetails().isEmpty()) {
                response.put("msg", "Maintenance details are required");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }

            boolean isScheduled = displayAreaService.scheduleMaintenance(maintenanceDto);

            if (isScheduled) {
                response.put("msg", "Maintenance scheduled successfully");
                response.put("areaId", maintenanceDto.getAreaId());
                response.put("scheduledTime", maintenanceDto.getScheduledTime().toString());
                response.put("maintenanceDetails", maintenanceDto.getMaintenanceDetails());
                return ResponseEntity.ok(response);
            } else {
                response.put("msg", "Failed to schedule maintenance");
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
            }
        } catch (Exception e) {
            response.put("msg", "An error occurred while scheduling maintenance");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }


    @GetMapping("/artifacts/{id}/status")
    public ResponseEntity<?> trackArtifactStatus(@PathVariable Long id) {
        HashMap<String, Object> response = new HashMap<>();

        try {
            ArtifactStatusDto statusDto = artifactService.getArtifactStatus(id);

            if (statusDto != null) {
                response.put("msg", "Artifact status retrieved successfully");
                response.put("artifactId", statusDto.getArtifactId());
                response.put("status", statusDto.getStatus());
                response.put("description", statusDto.getDescription());
                response.put("lastUpdated", statusDto.getLastUpdated().toString());
                return ResponseEntity.ok(response);
            } else {
                response.put("msg", "Artifact not found");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }
        } catch (Exception e) {
            response.put("msg", "An error occurred while retrieving artifact status");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletRequest request) {
        try{
            HttpSession session = request.getSession(false);
            if(session!=null){
                session.invalidate();
            }
            return new ResponseEntity<>(Map.of("msg","Logout successful"),HttpStatus.OK);
        }
        catch (Exception e){
            return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


}
