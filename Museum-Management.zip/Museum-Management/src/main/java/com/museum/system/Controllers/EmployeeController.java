package com.museum.system.Controllers;

import com.museum.system.Entities.Artifact;
import com.museum.system.Entities.Role;
import com.museum.system.Entities.User;
import com.museum.system.Services.IArtifactService;
import com.museum.system.Services.Impl.DisplayAreaService;
import com.museum.system.Services.Impl.UserService;
import com.museum.system.dtos.ArtifactStatusDto;
import com.museum.system.dtos.LoginDto;
import com.museum.system.dtos.MaintenanceDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Handler;

@RestController
@RequestMapping("api/employee")
public class EmployeeController {

    @Autowired
    private IArtifactService artifactService;

    @Autowired
    private DisplayAreaService displayAreaService;

    @Autowired
    private UserService userService;

    @PostMapping("/message")
    public Map<String, String> msg(){
        return Map.of("msg","Connection in employee controller");
    }

    @PostMapping("/assign-artifact")
    public ResponseEntity<Artifact> assignArtifact(@RequestBody Artifact artifact) {
        return ResponseEntity.ok(artifactService.createArtifact(artifact));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody HashMap<String,String> loginDto) {
        HashMap<String,Object> response =new HashMap<>();
        try{
            String username = loginDto.get("username");
            String password = loginDto.get("password");

            if(username == null && password == null){
                response.put("msg","Username and password fields are required");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }

            Optional<User> userDetails = userService.login(username, password);
            if(userDetails.isPresent()){
                User user = userDetails.get();

                if(user.getRole() == Role.EMPLOYEE){
                    response.put("msg","Employee logged in successfully");
                    response.put("userID",userDetails.get().getId());
                    response.put("username",userDetails.get().getUsername());
                    return ResponseEntity.ok(response);
                }
                else {
                    response.put("msg", "Access denied: Only employees can log in");
                    return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
                }
            }
            else{
                response.put("msg","Invalid username and password");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }
        }
        catch (Exception e){
            response.put("msg","An error occured during login");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PutMapping("/display-areas/{areaId}/assign")
    public ResponseEntity<String> assignArtifacts(@PathVariable Long areaId, @RequestBody List<Long> artifactIds) {
        displayAreaService.assignArtifacts(areaId, artifactIds);
        return ResponseEntity.ok("Artifacts assigned successfully");
    }

    // Schedule maintenance
    @PostMapping("/maintenance/schedule")
    public ResponseEntity<String> scheduleMaintenance(@RequestBody MaintenanceDto maintenanceDto) {
        displayAreaService.scheduleMaintenance(maintenanceDto);
        return ResponseEntity.ok("Maintenance scheduled successfully");
    }

    // Track artifact status
    @GetMapping("/artifacts/{id}/status")
    public ResponseEntity<ArtifactStatusDto> trackArtifactStatus(@PathVariable Long id) {
        ArtifactStatusDto status = artifactService.getArtifactStatus(id);
        return ResponseEntity.ok(status);
    }

    // Employee logout
    @PostMapping("/logout")
    public ResponseEntity<String> logout() {
        // Implement logout logic
        return ResponseEntity.ok("Employee logged out successfully");
    }







}
