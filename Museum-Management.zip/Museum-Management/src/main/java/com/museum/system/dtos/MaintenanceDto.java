package com.museum.system.dtos;

import java.time.LocalDateTime;

public class MaintenanceDto {

    private Long areaId;  // The ID of the display area
    private LocalDateTime scheduledTime;  // When the maintenance is scheduled
    private String maintenanceDetails;  // Optional details or description of the maintenance

    // Default constructor
    public MaintenanceDto() {}

    // Parameterized constructor
    public MaintenanceDto(Long areaId, LocalDateTime scheduledTime, String maintenanceDetails) {
        this.areaId = areaId;
        this.scheduledTime = scheduledTime;
        this.maintenanceDetails = maintenanceDetails;
    }

    // Getters and setters
    public Long getAreaId() {
        return areaId;
    }

    public void setAreaId(Long areaId) {
        this.areaId = areaId;
    }

    public LocalDateTime getScheduledTime() {
        return scheduledTime;
    }

    public void setScheduledTime(LocalDateTime scheduledTime) {
        this.scheduledTime = scheduledTime;
    }

    public String getMaintenanceDetails() {
        return maintenanceDetails;
    }

    public void setMaintenanceDetails(String maintenanceDetails) {
        this.maintenanceDetails = maintenanceDetails;
    }

    // toString() for logging
    @Override
    public String toString() {
        return "MaintenanceDto{" +
                "areaId=" + areaId +
                ", scheduledTime=" + scheduledTime +
                ", maintenanceDetails='" + maintenanceDetails + '\'' +
                '}';
    }
}
