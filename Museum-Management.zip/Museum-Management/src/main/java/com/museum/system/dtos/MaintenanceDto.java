package com.museum.system.dtos;

import java.time.LocalDateTime;

public class MaintenanceDto {

    private Long areaId;
    private LocalDateTime scheduledTime;
    private String maintenanceDetails;


    public MaintenanceDto() {}


    public MaintenanceDto(Long areaId, LocalDateTime scheduledTime, String maintenanceDetails) {
        this.areaId = areaId;
        this.scheduledTime = scheduledTime;
        this.maintenanceDetails = maintenanceDetails;
    }

    public Long getAreaId() {
        return areaId;
    }

    public void setAreaId(Long areaId) {
        this.areaId = areaId;
    }

    public LocalDateTime getScheduledTime() {
        return scheduledTime;
    }

    public void setScheduledTime(LocalDateTime scheduledTime) {
        this.scheduledTime = scheduledTime;
    }

    public String getMaintenanceDetails() {
        return maintenanceDetails;
    }

    public void setMaintenanceDetails(String maintenanceDetails) {
        this.maintenanceDetails = maintenanceDetails;
    }

    @Override
    public String toString() {
        return "MaintenanceDto{" +
                "areaId=" + areaId +
                ", scheduledTime=" + scheduledTime +
                ", maintenanceDetails='" + maintenanceDetails + '\'' +
                '}';
    }
}
