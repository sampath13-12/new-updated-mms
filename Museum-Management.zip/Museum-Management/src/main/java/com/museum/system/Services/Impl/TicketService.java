package com.museum.system.Services.Impl;

import com.museum.system.Entities.Ticket;
import com.museum.system.Repositories.ITicketRepository;
import com.museum.system.Services.ITicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TicketService implements ITicketService {
    @Autowired
    private ITicketRepository ticketRepository;

    @Override
    public Ticket purchaseTicket(Ticket ticket) {
        return ticketRepository.save(ticket);
    }
}
