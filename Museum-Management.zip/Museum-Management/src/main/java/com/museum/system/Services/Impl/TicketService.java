package com.museum.system.Services.Impl;

import com.museum.system.Entities.Ticket;
import com.museum.system.Entities.User;
import com.museum.system.Repositories.ITicketRepository;
import com.museum.system.Repositories.IUserRepository;
import com.museum.system.Services.ITicketService;
import com.museum.system.dtos.TicketDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TicketService implements ITicketService {
    @Autowired
    private ITicketRepository ticketRepository;

    @Autowired
    private IUserRepository userRepository;

    public class TicketMapper {
        public static Ticket toEntity(TicketDto dto, User user) {
            Ticket ticket = new Ticket();
            ticket.setTicketNumber(dto.getTicketNumber());
            ticket.setDate(dto.getDate());
            ticket.setPrice(dto.getPrice());
            ticket.setUser(user);
            return ticket;
        }

        public static TicketDto toDto(Ticket ticket) {
            return new TicketDto(
                    ticket.getTicketNumber(),
                    ticket.getDate(),
                    ticket.getPrice(),
                    ticket.getUser().getId()
            );
        }
    }

    @Override
    public Ticket purchaseTicket(TicketDto ticketDto) {
        User user = userRepository.findById(ticketDto.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Map TicketDto to Ticket entity
        Ticket ticket = TicketMapper.toEntity(ticketDto, user);

        // Save the Ticket entity
        return ticketRepository.save(ticket);
    }
}
