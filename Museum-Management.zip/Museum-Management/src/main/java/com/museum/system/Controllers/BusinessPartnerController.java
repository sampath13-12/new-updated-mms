package com.museum.system.Controllers;

import com.museum.system.Entities.Loan;
import com.museum.system.Services.Impl.LoanService;
import com.museum.system.dtos.LoanDto;
import com.museum.system.dtos.LoanRequestDto;
import com.museum.system.dtos.LoginDto;
import com.museum.system.dtos.NotificationDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("api/business-partner")
public class BusinessPartnerController {
    @Autowired
    private LoanService loanService;

    @PostMapping("/message")
    public Map<String, String> msg(){
        return Map.of("msg","Connection in business partner controller");
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginDto loginDto) {
        // Implement login logic
        return ResponseEntity.ok("Business Partner logged in successfully");
    }

    // View loaned artifacts
    @GetMapping("/loans")
    public ResponseEntity<List<LoanDto>> getLoanedArtifacts() {
        List<LoanDto> loanedArtifacts = loanService.getLoanedArtifacts();
        return ResponseEntity.ok(loanedArtifacts);
    }

    // Check loan status
    @GetMapping("/loans/{loanId}/status")
    public ResponseEntity<String> checkLoanStatus(@PathVariable Long loanId) {
        String status = loanService.getLoanStatus(loanId);
        return ResponseEntity.ok(status);
    }

    // Request new loan
    @PostMapping("/loans/request")
    public ResponseEntity<String> requestLoan(@RequestBody LoanRequestDto loanRequestDto) {
        loanService.requestLoan((Loan) loanRequestDto);
        return ResponseEntity.ok("Loan requested successfully");
    }

    // Receive notifications
    @GetMapping("/notifications")
    public ResponseEntity<List<NotificationDto>> getNotifications() {
        List<NotificationDto> notifications = loanService.getNotifications();
        return ResponseEntity.ok(notifications);
    }

    // Business partner logout
    @PostMapping("/logout")
    public ResponseEntity<String> logout() {
        // Implement logout logic
        return ResponseEntity.ok("Business Partner logged out successfully");
    }
}
