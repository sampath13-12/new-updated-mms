package com.museum.system.Controllers;

import com.museum.system.Entities.Loan;
import com.museum.system.Services.Impl.LoanService;
import com.museum.system.dtos.LoanDto;
import com.museum.system.dtos.LoanRequestDto;
import com.museum.system.dtos.LoginDto;
import com.museum.system.dtos.NotificationDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("api/business-partner")
public class BusinessPartnerController {

    @Autowired
    private LoanService loanService;

    // Test endpoint to check if the business partner controller is working
    @PostMapping("/message")
    public Map<String, String> msg() {
        return Map.of("msg", "Connection in business partner controller");
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginDto loginDto) {
        HashMap<String, Object> response = new HashMap<>();
        try {
            if (loginDto.getUsername() == null || loginDto.getPassword() == null) {
                response.put("msg", "Username and password are required");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }

            // Add authentication logic here
            boolean isAuthenticated = authenticateBusinessPartner(loginDto); // Placeholder authentication logic
            if (isAuthenticated) {
                response.put("msg", "Business Partner logged in successfully");
                return ResponseEntity.ok(response);
            } else {
                response.put("msg", "Invalid credentials");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }
        } catch (Exception e) {
            response.put("msg", "An error occurred during login");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // View loaned artifacts
    @GetMapping("/loans")
    public ResponseEntity<?> getLoanedArtifacts() {
        HashMap<String, Object> response = new HashMap<>();
        try {
            List<LoanDto> loanedArtifacts = loanService.getLoanedArtifacts();
            response.put("loanedArtifacts", loanedArtifacts);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("msg", "An error occurred while retrieving loaned artifacts");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // Check loan status
    @GetMapping("/loans/{loanId}/status")
    public ResponseEntity<?> checkLoanStatus(@PathVariable Long loanId) {
        HashMap<String, Object> response = new HashMap<>();
        try {
            String status = loanService.getLoanStatus(loanId);
            response.put("loanStatus", status);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("msg", "An error occurred while retrieving the loan status");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // Request new loan
    @PostMapping("/loans/request")
    public ResponseEntity<?> requestLoan(@RequestBody LoanRequestDto loanRequestDto) {
        HashMap<String, Object> response = new HashMap<>();
        try {
            Loan loan = loanService.requestLoan(loanRequestDto);
            LoanDto loanDto = new LoanDto(
                    loan.getArtifact().getId(),          // Get artifact ID
                    loan.getArtifact().getName(),        // Get artifact name
                    loan.getStatus()                     // Get loan status
            );
            response.put("msg", "Loan requested successfully for artifact " + loan.getArtifact().getName());
            response.put("loan",loanDto);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("msg", "An error occurred while processing the loan request: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // Receive notifications
    @GetMapping("/notifications")
    public ResponseEntity<?> getNotifications() {
        HashMap<String, Object> response = new HashMap<>();
        try {
            List<NotificationDto> notifications = loanService.getNotifications();
            response.put("notifications", notifications);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("msg", "An error occurred while retrieving notifications");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // Business partner logout
    @PostMapping("/logout")
    public ResponseEntity<?> logout() {
        HashMap<String, Object> response = new HashMap<>();
        try {
            // Implement the actual logout logic here if necessary
            response.put("msg", "Business Partner logged out successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("msg", "An error occurred during logout");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    private boolean authenticateBusinessPartner(LoginDto loginDto) {
        return loginDto.getUsername().equals("businessPartner") && loginDto.getPassword().equals("password");
    }
}
