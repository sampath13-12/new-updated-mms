package com.museum.system.Services.Impl;

import com.museum.system.Entities.Artifact;
import com.museum.system.Repositories.IArtifactRepository;
import com.museum.system.Services.IArtifactService;
import com.museum.system.dtos.ArtifactDto;
import com.museum.system.dtos.ArtifactStatusDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class ArtifactService implements IArtifactService {

    @Autowired
    private IArtifactRepository artifactRepository;

    private List<ArtifactDto> artifactList = new ArrayList<>();

    @Override
    public Artifact createArtifact(Artifact artifact) {
        return null;
    }

    @Override
    public List<ArtifactDto> getAllArtifacts() {
         return artifactList;
    }

    @Override
    public void addArtifact(ArtifactDto artifactDto) {
        Artifact artifact = new Artifact();
        artifact.setName(artifactDto.getName());
        artifact.setDescription(artifactDto.getDescription());
        artifact.setStatus(artifactDto.getStatus());
        artifact.setLocation(artifactDto.getLocation());
        artifactRepository.save(artifact);
    }

    @Override
    public ArtifactStatusDto getArtifactStatus(Long id) {
        Artifact artifact = artifactRepository.findById(id).orElse(null);
        if (artifact == null) {
            return null;
        }
        return new ArtifactStatusDto(
                artifact.getId(),
                artifact.getStatus(),
                artifact.getDescription(),
                LocalDateTime.now()
        );
    }

    @Override
    public boolean removeArtifact(Long id) {
        Artifact artifact = artifactRepository.findById(id).orElse(null);
        if (artifact != null) {
            artifactRepository.delete(artifact);
            return true;
        }
        return false;
    }
}
