package com.museum.system.Services.Impl;

import com.museum.system.Entities.Artifact;
import com.museum.system.Repositories.IArtifactRepository;
import com.museum.system.Services.IArtifactService;
import com.museum.system.dtos.ArtifactDto;
import com.museum.system.dtos.ArtifactStatusDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ArtifactService implements IArtifactService {

    @Autowired
    private IArtifactRepository artifactRepository;

    @Override
    public Artifact createArtifact(Artifact artifact) {
        return null;
    }

    @Override
    public List<Artifact> getAllArtifacts() {
        return List.of();
    }

    @Override
    public void addArtifact(ArtifactDto artifactDto) {

    }

    @Override
    public ArtifactStatusDto getArtifactStatus(Long id) {
        return null;
    }

    @Override
    public void removeArtifact(Long id) {

    }
}
