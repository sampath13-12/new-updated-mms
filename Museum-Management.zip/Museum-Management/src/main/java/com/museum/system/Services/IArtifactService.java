package com.museum.system.Services;

import com.museum.system.Entities.Artifact;
import com.museum.system.dtos.ArtifactDto;
import com.museum.system.dtos.ArtifactStatusDto;

import java.util.List;

public interface IArtifactService {
    public Artifact createArtifact(Artifact artifact) ;

    public List<ArtifactDto> getAllArtifacts() ;

    void addArtifact(ArtifactDto artifactDto);

    ArtifactStatusDto getArtifactStatus(Long id);

    boolean removeArtifact(Long id);
}
