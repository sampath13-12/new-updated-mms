package com.museum.system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EntityScan(basePackages = "com.museum.system.Entities")
@EnableJpaRepositories("com.museum.system.Repositories")
public class MuseumManagementApplication {

	public static void main(String[] args) {

		SpringApplication.run(MuseumManagementApplication.class, args);
		System.out.println("Execution started.......");
	}

}
