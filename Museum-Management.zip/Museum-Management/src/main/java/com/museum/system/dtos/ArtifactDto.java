package com.museum.system.dtos;

public class ArtifactDto {
    private String name;
    private String description;
    private String artist;
    private String year;

    public ArtifactDto() {
    }

    public ArtifactDto(String name, String description, String artist, String year) {
        this.name = name;
        this.description = description;
        this.artist = artist;
        this.year = year;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }


    @Override
    public String toString() {
        return "ArtifactDto{" +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", artist='" + artist + '\'' +
                ", year='" + year + '\'' +
                '}';
    }
}
