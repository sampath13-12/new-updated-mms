package com.museum.system.dtos;


import lombok.Data;

@Data
public class ArtifactDto {
    private String name;
    private String description;
    private String status;
    private String location;
}
