package com.museum.system.Services.Impl;

import com.museum.system.Entities.Notification;
import com.museum.system.Repositories.INotificationRepository;
import com.museum.system.Services.INotificationService;
import com.museum.system.dtos.NotificationDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NotificationService implements INotificationService {

    @Autowired
    private INotificationRepository notificationRepository;

    @Override
    public Notification createNotification(Notification notification) {
        return notificationRepository.save(notification);
    }

    @Override
    public List<NotificationDto> getNotifications() {
        return List.of();
    }
}
