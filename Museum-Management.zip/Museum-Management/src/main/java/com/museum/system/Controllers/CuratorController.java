package com.museum.system.Controllers;

import com.museum.system.Services.IArtifactService;
import com.museum.system.Services.Impl.DisplayAreaService;
import com.museum.system.Services.Impl.LoanService;
import com.museum.system.Services.Impl.NotificationService;
import com.museum.system.dtos.ArtifactDto;
import com.museum.system.dtos.DisplayAreaDto;
import com.museum.system.dtos.LoginDto;
import com.museum.system.dtos.NotificationDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("api/curator")
public class CuratorController {

    @Autowired
    private IArtifactService artifactService;
    @Autowired
    private DisplayAreaService displayAreaService;
    @Autowired
    private LoanService loanService;

    // Test endpoint to check if curator controller is working
    @PostMapping("/message")
    public Map<String, String> msg() {
        return Map.of("msg", "Connection in curator controller");
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginDto loginDto) {
        HashMap<String, Object> response = new HashMap<>();
        try {
            if (loginDto.getUsername() == null || loginDto.getPassword() == null) {
                response.put("msg", "Username and password are required");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }

            // Assuming you have some logic to authenticate the curator
            boolean isAuthenticated = authenticateCurator(loginDto); // Replace with actual authentication logic
            if (isAuthenticated) {
                response.put("msg", "Curator logged in successfully");
                return ResponseEntity.ok(response);
            } else {
                response.put("msg", "Invalid credentials");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }
        } catch (Exception e) {
            response.put("msg", "An error occurred during login");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PostMapping("/artifacts")
    public ResponseEntity<?> addArtifact(@RequestBody ArtifactDto artifactDto) {
        HashMap<String, Object> response = new HashMap<>();
        try {
            if (artifactDto.getName() == null || artifactDto.getDescription() == null) {
                response.put("msg", "Artifact name and description are required");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }

            artifactService.addArtifact(artifactDto);
            response.put("msg", "Artifact added to collection");
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception e) {
            response.put("msg", "An error occurred while adding the artifact");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }


    @DeleteMapping("/artifacts/{id}")
    public ResponseEntity<?> removeArtifact(@PathVariable Long id) {
        HashMap<String, Object> response = new HashMap<>();
        try {
            boolean isRemoved = artifactService.removeArtifact(id);
            if (isRemoved) {
                response.put("msg", "Artifact removed from collection");
                return ResponseEntity.ok(response);
            } else {
                response.put("msg", "Artifact not found");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }
        } catch (Exception e) {
            response.put("msg", "An error occurred while removing the artifact");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // Approve loan request
    @PutMapping("/loans/{loanId}/approve")
    public ResponseEntity<?> approveLoan(@PathVariable Long loanId) {
        HashMap<String, Object> response = new HashMap<>();
        try {
            boolean isApproved = loanService.approveLoan(loanId);
            if (isApproved) {
                response.put("msg", "Loan approved");
                return ResponseEntity.ok(response);
            } else {
                response.put("msg", "Loan not found or cannot be approved");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }
        } catch (Exception e) {
            response.put("msg", "An error occurred while approving the loan");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // Update display area
    @PutMapping("/display-areas/{areaId}")
    public ResponseEntity<?> updateDisplayArea(@PathVariable Long areaId, @RequestBody DisplayAreaDto displayAreaDto) {
        HashMap<String, Object> response = new HashMap<>();
        try {
            boolean isUpdated = displayAreaService.updateDisplayArea(areaId, displayAreaDto);
            if (isUpdated) {
                response.put("msg", "Display area updated");
                return ResponseEntity.ok(response);
            } else {
                response.put("msg", "Display area not found");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }
        } catch (Exception e) {
            response.put("msg", "An error occurred while updating the display area");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // Get curator notifications
    @GetMapping("/notifications")
    public ResponseEntity<?> getNotifications() {
        HashMap<String, Object> response = new HashMap<>();
        try {
            List<NotificationDto> notifications = loanService.getNotifications();
            response.put("notifications", notifications);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("msg", "An error occurred while retrieving notifications");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // Curator logout
    @PostMapping("/logout")
    public ResponseEntity<?> logout() {
        HashMap<String, Object> response = new HashMap<>();
        try {
            // Implement the actual logout logic if necessary
            response.put("msg", "Curator logged out successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("msg", "An error occurred during logout");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    private boolean authenticateCurator(LoginDto loginDto) {
        return loginDto.getUsername().equals("curator") && loginDto.getPassword().equals("password");
    }
}
