package com.museum.system.Controllers;

import com.museum.system.Services.IArtifactService;
import com.museum.system.Services.Impl.DisplayAreaService;
import com.museum.system.Services.Impl.LoanService;
import com.museum.system.Services.Impl.NotificationService;
import com.museum.system.dtos.ArtifactDto;
import com.museum.system.dtos.DisplayAreaDto;
import com.museum.system.dtos.LoginDto;
import com.museum.system.dtos.NotificationDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("api/curator")
public class CuratorController {
    @Autowired
    private IArtifactService artifactService;
    @Autowired
    private DisplayAreaService displayAreaService;
    @Autowired
    private LoanService loanService;

    @PostMapping("/message")
    public Map<String, String> msg(){
        return Map.of("msg","Connection in curator controller");
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginDto loginDto) {
        // Implement login logic
        return ResponseEntity.ok("Curator logged in successfully");
    }

    // Add new artifact to collection
    @PostMapping("/artifacts")
    public ResponseEntity<String> addArtifact(@RequestBody ArtifactDto artifactDto) {
        artifactService.addArtifact(artifactDto);
        return ResponseEntity.ok("Artifact added to collection");
    }

    // Remove artifact from collection
    @DeleteMapping("/artifacts/{id}")
    public ResponseEntity<String> removeArtifact(@PathVariable Long id) {
        artifactService.removeArtifact(id);
        return ResponseEntity.ok("Artifact removed from collection");
    }

    // Approve loan request
    @PutMapping("/loans/{loanId}/approve")
    public ResponseEntity<String> approveLoan(@PathVariable Long loanId) {
        loanService.approveLoan(loanId);
        return ResponseEntity.ok("Loan approved");
    }

    // Update display area
    @PutMapping("/display-areas/{areaId}")
    public ResponseEntity<String> updateDisplayArea(@PathVariable Long areaId, @RequestBody DisplayAreaDto displayAreaDto) {
        displayAreaService.updateDisplayArea(areaId, displayAreaDto);
        return ResponseEntity.ok("Display area updated");
    }

    // Receive notifications
    @GetMapping("/notifications")
    public ResponseEntity<List<NotificationDto>> getNotifications() {
        List<NotificationDto> notifications = loanService.getNotifications();
        return ResponseEntity.ok(notifications);
    }

    // Curator logout
    @PostMapping("/logout")
    public ResponseEntity<String> logout() {
        // Implement logout logic
        return ResponseEntity.ok("Curator logged out successfully");
    }
}
