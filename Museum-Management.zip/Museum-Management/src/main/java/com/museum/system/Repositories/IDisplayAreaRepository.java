package com.museum.system.Repositories;

import com.museum.system.Entities.DisplayArea;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface IDisplayAreaRepository extends JpaRepository<DisplayArea, Long> {

}
