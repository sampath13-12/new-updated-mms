package com.museum.system.Entities;

public enum Status {
    ON_DISPLAY,
    IN_WAREHOUSE,
    ON_LOAN,
    IN_RESTORATION
}
