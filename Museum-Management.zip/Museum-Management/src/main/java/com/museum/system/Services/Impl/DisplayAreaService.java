package com.museum.system.Services.Impl;

import com.museum.system.Entities.DisplayArea;
import com.museum.system.Repositories.IDisplayAreaRepository;
import com.museum.system.Services.IDisplayAreaService;
import com.museum.system.dtos.DisplayAreaDto;
import com.museum.system.dtos.MaintenanceDto;
import org.hibernate.validator.internal.util.stereotypes.Lazy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service
public class DisplayAreaService implements IDisplayAreaService {


    @Autowired
    private IDisplayAreaRepository displayAreaRepository;

    @Override
    public DisplayArea createDisplayArea(DisplayArea displayArea) {

        return displayAreaRepository.save(displayArea);
    }

    @Override
    public void updateDisplayArea(Long areaId, DisplayAreaDto displayAreaDto) {

    }

    public void assignArtifacts(Long areaId, List<Long> artifactIds) {
    }

    public void scheduleMaintenance(MaintenanceDto maintenanceDto) {
    }
}
