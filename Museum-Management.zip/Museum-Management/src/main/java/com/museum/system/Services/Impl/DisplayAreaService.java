package com.museum.system.Services.Impl;

import com.museum.system.Entities.DisplayArea;
import com.museum.system.Entities.Maintenance;
import com.museum.system.Repositories.IDisplayAreaRepository;
import com.museum.system.Repositories.IMaintenanceRepository;
import com.museum.system.Services.IDisplayAreaService;
import com.museum.system.dtos.DisplayAreaDto;
import com.museum.system.dtos.MaintenanceDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
public class DisplayAreaService implements IDisplayAreaService {

    Logger logger = LoggerFactory.getLogger(DisplayAreaService.class);

    @Autowired
    private IMaintenanceRepository maintenanceRepository;
    @Autowired
    private IDisplayAreaRepository displayAreaRepository;

    private List<DisplayAreaDto> displayAreaList = new ArrayList<>();

    @Override
    public DisplayArea createDisplayArea(DisplayArea displayArea) {
        return displayAreaRepository.save(displayArea);
    }

    @Override
    public boolean updateDisplayArea(Long areaId, DisplayAreaDto displayAreaDto) {
        for (DisplayAreaDto area : displayAreaList) {
            if (area.getAreaName().equals("Area" + areaId)) {
                area.setAreaName(displayAreaDto.getAreaName());
                area.setLocation(displayAreaDto.getLocation());
                area.setLayout(displayAreaDto.getLayout());
                return true;
            }
        }
        return false;
    }

    @Override
    public void addDisplayArea(DisplayAreaDto displayAreaDto) {
        displayAreaList.add(displayAreaDto);
    }

    @Override
    public List<DisplayAreaDto> getAllDisplayAreas() {
        return displayAreaList;
    }

    public boolean assignArtifacts(Long areaId, List<Long> artifactIds) {
        return false;
    }

    public boolean scheduleMaintenance(MaintenanceDto maintenanceDto) {
        Maintenance maintenance = new Maintenance(
                maintenanceDto.getAreaId(),
                maintenanceDto.getScheduledTime(),
                maintenanceDto.getMaintenanceDetails()
        );

        try {
            maintenanceRepository.save(maintenance);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
